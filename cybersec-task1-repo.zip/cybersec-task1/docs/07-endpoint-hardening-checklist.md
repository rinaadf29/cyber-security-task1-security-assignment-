# 7. Endpoint Hardening Checklist

**Scope:** all employee laptops (A-01) and the file server (A-02).
**Purpose:** reduce the attack surface of every device before an attacker reaches it.
**How to use:** work top to bottom for each device; record the date and initials of whoever verified each item.

---

## 7.1 Updates and patch management

- [ ] Operating system is a currently supported version (no end-of-life builds)
- [ ] Automatic OS updates enabled and confirmed applying — not merely "set"
- [ ] Critical and security patches installed within **7 days** of release
- [ ] Browsers (Chrome, Edge, Firefox) set to auto-update
- [ ] Third-party applications patched: Office, Adobe Reader, Java, VPN client, PDF tools
- [ ] Firmware and BIOS/UEFI updated from the vendor
- [ ] Unused and unnecessary software removed to shrink the attack surface
- [ ] Unnecessary services and startup items disabled
- [ ] Monthly patch-compliance report produced and any exception documented with a compensating control

## 7.2 Passwords and authentication

- [ ] Unique password per account — no reuse across work and personal services
- [ ] Minimum **14 characters**, passphrase style encouraged (`correct-horse-battery-staple` beats `P@ssw0rd1`)
- [ ] Passwords screened against known-breached password lists
- [ ] All default credentials changed on every device and application
- [ ] Shared accounts eliminated — every login maps to a named individual for accountability
- [ ] Account lockout after 5 failed attempts, with a 15-minute cooldown
- [ ] Screen lock after **10 minutes** idle, password required on wake
- [ ] Organization-approved password manager deployed and staff trained on it
- [ ] Credentials never stored in plaintext files, spreadsheets or browser-saved form data on shared devices
- [ ] Password policy enforced centrally by Group Policy or MDM, not left to individuals

## 7.3 Multi-factor authentication

- [ ] MFA enforced on all cloud accounts (Microsoft 365, cloud provider consoles, registrar)
- [ ] MFA required for VPN and any remote access
- [ ] MFA on the customer-portal administrative interface
- [ ] Authenticator app or FIDO2 hardware key used in preference to SMS (SMS is vulnerable to SIM swapping)
- [ ] Number-matching / push-fatigue protection enabled where the platform supports it
- [ ] Backup recovery codes generated and stored securely offline
- [ ] A documented, identity-verified process exists for MFA reset — this process is itself a phishing target
- [ ] Conditional access policies applied (block legacy authentication, flag impossible travel)

## 7.4 Host firewall

- [ ] Host-based firewall enabled on every endpoint — including on the internal LAN, not just when remote
- [ ] Default inbound policy set to **deny**
- [ ] Only required inbound rules present, each documented
- [ ] File and printer sharing disabled on laptops (the file server provides it centrally)
- [ ] Remote Desktop (3389) disabled on endpoints; if genuinely needed, reachable only over VPN
- [ ] Separate, stricter firewall profile for public networks (cafés, airports, hotels)
- [ ] Firewall settings locked so standard users cannot disable them
- [ ] Firewall logging enabled and forwarded to central logging (C-10)

## 7.5 Antivirus / EDR

- [ ] EDR agent installed on **100%** of endpoints and the server — coverage gaps are where incidents start
- [ ] Real-time protection enabled and tamper protection turned on
- [ ] Signatures and behavioural models updating automatically
- [ ] Cloud-delivered protection and automatic sample submission enabled
- [ ] Central management console in place with alerting to a named person
- [ ] Weekly full scan scheduled outside working hours
- [ ] Ransomware-specific protection enabled (controlled folder access / behavioural rollback)
- [ ] Web and download protection blocking known-malicious sites
- [ ] Email attachment and macro protection enabled — Office macros from the Internet blocked by policy
- [ ] Alerts monitored daily; a documented response procedure exists for a detection

## 7.6 Least privilege

- [ ] Standard users do **not** hold local administrator rights
- [ ] IT staff use separate accounts: a standard account for daily work, an admin account only for admin tasks
- [ ] Admin accounts never used for email or web browsing
- [ ] Built-in Administrator and Guest accounts disabled or renamed
- [ ] Application installation restricted to IT; application allow-listing considered for high-risk roles
- [ ] File-share permissions assigned by security group, following need-to-know
- [ ] UAC (Windows) set to always notify; `sudo` use logged on macOS/Linux
- [ ] Quarterly access review conducted and documented
- [ ] Accounts disabled on the **same day** an employee leaves
- [ ] USB and removable-media policy enforced (block, or allow read-only with encryption)

## 7.7 Backup and recovery

- [ ] User data stored on the file server or approved cloud storage, not only on local disks
- [ ] Automated daily backup covering all critical data
- [ ] **3-2-1-1-0 rule** satisfied: 3 copies, 2 media types, 1 offsite, 1 immutable/offline, 0 verification errors
- [ ] Backups encrypted in transit and at rest
- [ ] Backup storage isolated from the production network and **not** mounted as a writable drive letter
- [ ] Backup jobs monitored, with alerting on failure
- [ ] **Test restore performed and documented quarterly** — an unverified backup is only a hope, not a control
- [ ] RTO (4 hours) and RPO (24 hours) defined, agreed with the business, and measured during the test restore
- [ ] Recovery procedure documented and stored where it remains accessible during an outage (i.e. not only on the server being restored)

## 7.8 Data protection and encryption

- [ ] Full-disk encryption enabled: BitLocker (Windows) / FileVault (macOS)
- [ ] Recovery keys escrowed centrally in Active Directory, Intune or the MDM
- [ ] Removable media encrypted or blocked
- [ ] Secure wipe procedure defined for device disposal, reassignment or return
- [ ] Remote-wipe capability available for lost or stolen devices
- [ ] Sensitive data not stored locally where a server or approved cloud location is available
- [ ] Clear-desk and lock-screen practice observed in the office

## 7.9 Configuration and monitoring

- [ ] Devices enrolled in MDM (Intune, Jamf or equivalent) with configuration baselines applied
- [ ] Secure Boot and TPM enabled in firmware
- [ ] BIOS/UEFI password set to prevent boot-order tampering
- [ ] PowerShell logging / script-block logging enabled (Windows)
- [ ] Endpoint logs forwarded to central collection with 90-day retention
- [ ] Device present in the asset inventory (Document 01) with an assigned owner
- [ ] Standard, hardened build image used for all new devices
- [ ] Configuration drift reviewed against the baseline every quarter

---

## 7.10 Verification record

| Device ID | User | OS / build | Checked by | Date | Items passed | Exceptions raised |
|---|---|---|---|---|---|---|
| LAP-001 | | | | | / 80 | |
| LAP-002 | | | | | / 80 | |
| SRV-001 | — (file server) | | | | / 80 | |

---

## 7.11 Priority order if time is limited

If only one hour is available per device, do these seven things in this order. They remove the majority of realistic endpoint risk:

1. **Enable MFA** on all cloud accounts (§7.3)
2. **Remove local administrator rights** (§7.6)
3. **Apply all outstanding patches** and enable auto-update (§7.1)
4. **Turn on full-disk encryption** (§7.8)
5. **Install and verify EDR** with tamper protection (§7.5)
6. **Enable the host firewall** with default-deny inbound (§7.4)
7. **Verify a backup restore actually works** (§7.7)

Every one of these is free or near-free. None requires new hardware.
