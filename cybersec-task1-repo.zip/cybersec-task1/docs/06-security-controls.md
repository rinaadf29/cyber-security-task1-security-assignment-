# 6. Security Controls

---

## 6.1 How controls are classified

Controls are described along two independent axes. Knowing both is what lets you spot gaps — an organization with only preventive controls has no idea when prevention fails.

**By function**

| Function | Purpose | Example |
|---|---|---|
| **Preventive** | Stop an incident from occurring | MFA, firewall rules, full-disk encryption |
| **Detective** | Identify that an incident is occurring or has occurred | EDR alerts, log monitoring, file-integrity checks |
| **Corrective** | Limit damage and restore normal operation | Backups and restore, incident response, isolating a host |
| **Deterrent** | Discourage an attacker from attempting | Warning banners, visible CCTV, acceptable-use policy |
| **Compensating** | Alternative when the primary control is not feasible | Enhanced monitoring on a legacy system that cannot be patched |

**By nature**

| Nature | Description | Example |
|---|---|---|
| **Technical (logical)** | Implemented in hardware or software | Firewall, EDR, encryption |
| **Administrative** | Policies, procedures, training | Password policy, onboarding/offboarding checklist |
| **Physical** | Protects the physical environment | Locked rack, door access control |

---

## 6.2 Recommended control set

| ID | Control | Domain | Function | Nature | Addresses | Implementation detail | Cost | Priority |
|---|---|---|---|---|---|---|---|---|
| **C-01** | **Strong password and account policy** | Account | Preventive | Administrative + Technical | V-03, T-01, T-04 | 14+ character minimum, passphrase-encouraged, screened against breached-password lists, no forced rotation without cause (NIST SP 800-63B), lockout after 5 failed attempts, eliminate the two shared admin accounts and issue named individual accounts | Free | **Immediate** |
| **C-02** | **Multi-factor authentication everywhere** | Account | Preventive | Technical | V-02, T-01, T-04 | Enforce MFA on M365, VPN, the portal admin panel, the registrar account and all cloud consoles. Prefer authenticator apps or FIDO2 hardware keys over SMS, which is vulnerable to SIM swapping. Microsoft reports MFA blocks the overwhelming majority of automated account-compromise attempts | Low | **Immediate** |
| **C-03** | **Firewall hardening and default-deny policy** | Network | Preventive | Technical | V-07, T-08 | Remove the WAN-facing admin interface, close forwarded port 3389, change all default credentials, apply default-deny inbound, document every rule with a business justification and review quarterly, enable firmware auto-update | Free | **Immediate** |
| **C-04** | **Network segmentation and wireless hardening** | Network | Preventive | Technical | V-05, V-14, T-02, T-07 | Implement the five VLANs from Document 04, enforce inter-VLAN deny-by-default, move switch/AP management to VLAN 99, upgrade to WPA3 (WPA3-Enterprise with RADIUS for corporate, isolated WPA3-Personal for guest), disable WPS, enable DHCP snooping and dynamic ARP inspection | Low–Medium | **High** |
| **C-05** | **Least privilege and privileged access management** | Account | Preventive | Technical + Administrative | V-04, V-08, T-02, T-06 | Remove local administrator rights from all standard users, create separate admin accounts used only for admin tasks (never for email or browsing), apply role-based access on file shares, conduct quarterly access reviews, and follow a formal joiner/mover/leaver process | Free | **High** |
| **C-06** | **Data access control and classification** | Data | Preventive | Technical + Administrative | V-08, T-06 | Replace `Everyone: Full Control` with group-based NTFS permissions, classify data as Public / Internal / Confidential / Restricted, restrict HR and payroll to the HR group, enable file-access auditing on sensitive folders | Free | **High** |
| **C-07** | **Patch and vulnerability management** | Endpoint + Network | Preventive | Technical + Administrative | V-01, T-02, T-05 | Monthly patch cycle with 7-day SLA for critical CVEs, automated OS updates on endpoints, quarterly authenticated vulnerability scanning, decommission or isolate end-of-life systems, maintain a patch exception register | Low | **Immediate** |
| **C-08** | **Endpoint encryption and device control** | Endpoint + Data | Preventive | Technical | V-06, T-03 | BitLocker (Windows) and FileVault (macOS) on every laptop with keys escrowed centrally, encrypted removable media only, remote-wipe capability via MDM/Intune, 10-minute screen lock | Free–Low | **High** |
| **C-09** | **Backup, recovery and business continuity** | Data | Corrective | Technical + Administrative | V-09, T-02, T-11 | Apply the **3-2-1-1-0 rule**: 3 copies, 2 media types, 1 offsite, 1 immutable/offline, 0 errors after verification. Convert the NAS to pull-based backup on an isolated VLAN, add encrypted cloud replication, define RTO 4 h / RPO 24 h, and perform documented test restores quarterly | Low–Medium | **Immediate** |
| **C-10** | **Centralised logging, monitoring and detection** | Network + Endpoint | Detective | Technical | V-10, V-11, T-06, T-09 | Deploy EDR (Microsoft Defender for Business or equivalent) on all endpoints and the server with a central console, forward firewall/server/M365 logs to a central store, retain 90 days minimum, alert on impossible travel, mass file access, new admin accounts and disabled security tooling | Medium | **High** |
| **C-11** | **Web application and transport security** | Data + Network | Preventive | Technical | V-12, V-13, T-09, T-10 | Renew and automate the TLS certificate, force HTTPS with HSTS, deploy a WAF/CDN in front of the portal (also mitigates DDoS), fix SQL injection using parameterised queries and prepared statements, validate and sanitise all input, add security headers, and run annual authorised penetration testing | Low–Medium | **Immediate** |
| **C-12** | **Email security and phishing defence** | Account + Data | Preventive + Detective | Technical + Administrative | V-15, V-16, T-01 | Set SPF to hard fail (`-all`), enable DKIM signing, publish DMARC at `p=quarantine` then `p=reject`, enable advanced anti-phishing and link/attachment scanning, add external-sender warning banners, create a one-click "report phishing" button | Low | **High** |
| **C-13** | **Security awareness training** | People | Preventive | Administrative | V-16, T-01, T-06 | Onboarding security induction plus quarterly 20-minute refreshers, simulated phishing campaigns run as a learning exercise (never punitive), a clear and blame-free reporting channel, and a short acceptable-use policy signed by all staff | Low | **High** |
| **C-14** | **Physical security** | Physical | Preventive + Deterrent | Physical | T-14, T-11, T-03 | Lock the server cupboard and network rack, restrict keys to IT, install a smoke detector and UPS, add a visitor sign-in process, relocate the backup NAS out of the server room, and enforce a clear-desk and lock-screen habit | Low | **Medium** |
| **C-15** | **Incident response plan** | Governance | Corrective | Administrative | All | A one-page IR plan naming roles, an escalation contact list, the six phases (Preparation → Identification → Containment → Eradication → Recovery → Lessons Learned), evidence-handling guidance, DPDP Act notification steps, and an annual tabletop exercise | Free | **Medium** |

**Total controls recommended: 15** (requirement: minimum 10), covering all four required domains:

| Domain | Controls |
|---|---|
| **Endpoint protection** | C-07, C-08, C-10 |
| **Network protection** | C-03, C-04, C-10, C-11 |
| **Account protection** | C-01, C-02, C-05, C-12 |
| **Data protection** | C-06, C-08, C-09, C-11 |
| **People and governance** | C-13, C-14, C-15 |

---

## 6.3 Defence in depth — layered application

A single control never holds. The value of the set above is that an attacker must defeat several independent layers in sequence:

| Layer | Controls | If the attacker gets past it… |
|---|---|---|
| **People** | C-13, C-12 | …a staff member clicks a phishing link |
| **Identity** | C-01, C-02 | …MFA blocks the stolen password |
| **Perimeter** | C-03, C-11 | …the firewall denies the inbound connection |
| **Network** | C-04, C-10 | …segmentation stops lateral movement to servers |
| **Endpoint** | C-07, C-08, C-10 | …EDR detects and quarantines the payload |
| **Data** | C-06, C-08 | …permissions and encryption limit what is readable |
| **Recovery** | C-09, C-15 | …verified immutable backups restore operations |

---

## 6.4 Prioritised remediation roadmap

| Phase | Timeframe | Actions | Risks addressed | Approx. cost |
|---|---|---|---|---|
| **Phase 1 — Emergency** | Week 1 | C-02 (enable MFA), C-03 (close WAN admin + port 3389, change default credentials), C-11 (renew certificate, force HTTPS), fix SQL injection | R-02, R-03, R-04, R-10 | Near zero |
| **Phase 2 — Foundation** | Weeks 2–4 | C-01, C-05 (remove local admin, retire shared accounts), C-07 (patch all systems), C-09 (fix backup isolation and run first test restore), C-08 (enable disk encryption) | R-01, R-05, R-06, R-11 | Low |
| **Phase 3 — Architecture** | Months 2–3 | C-04 (VLANs and WPA3), C-06 (rebuild share permissions), C-10 (deploy EDR and central logging), C-12 (DKIM/DMARC) | R-07, R-08, R-09, R-13 | Medium |
| **Phase 4 — Maturity** | Months 4–6 | C-13 (training programme), C-14 (physical security), C-15 (IR plan and tabletop), WAF/CDN, ISP failover, annual penetration test | Residual risk, R-12 | Medium |

**Expected outcome:** the three Critical risks drop to Low or Medium by the end of Phase 2, and the overall risk profile moves from *3 Critical / 6 High* to *0 Critical / 1 High* by the end of Phase 4.

Phases 1 and 2 together resolve the majority of the identified risk at almost no financial cost — they are configuration and discipline changes, not purchases. This is the single most useful finding of the assessment for a small business: most of the gap is not a budget problem.
