# 1. Asset Inventory and Classification

**Organization:** Northwind Craft Supplies Pvt. Ltd. (fictional)
**Size:** 25 employees, single office, one public-facing web service
**Assessed by:** Junior Cybersecurity Analyst
**Date:** September 2026

---

## 1.1 Why an asset inventory comes first

You cannot protect what you do not know you have. An asset inventory is the foundation of every security framework — it is Control 1 in the CIS Critical Security Controls and the first activity in the **Identify** function of the NIST Cybersecurity Framework. Every later deliverable in this report (threats, vulnerabilities, CIA ratings, controls) is anchored to a row in this table.

## 1.2 Classification scheme used

**Asset type**

| Type | Meaning |
|---|---|
| Hardware | Physical device with compute, storage or network function |
| Software | Operating systems, applications, services |
| Data | Information at rest or in transit, independent of the device holding it |
| Network | Connectivity, transport and edge-control components |
| Service | Externally provided or externally consumed capability |
| Identity | Accounts, credentials, groups and privilege |

**Importance (business criticality)**

| Level | Definition | Tolerable downtime |
|---|---|---|
| Critical | Loss halts business operations or causes legal/regulatory exposure | < 4 hours |
| High | Loss severely degrades operations or affects customers | < 24 hours |
| Medium | Loss causes inconvenience, workarounds exist | 1–3 days |
| Low | Minimal operational effect | > 3 days |

---

## 1.3 Asset inventory table

| # | Asset | Type | Description / Quantity | Location | Owner | Importance | Data sensitivity |
|---|---|---|---|---|---|---|---|
| A-01 | Employee laptops | Hardware + Software | 12 × Windows 11 laptops, 3 × macOS | Office / remote | IT Admin | **High** | Internal, some Confidential |
| A-02 | File server | Hardware + Software | 1 × Windows Server 2019, SMB shares, 4 TB | Office server cupboard | IT Admin | **Critical** | Confidential |
| A-03 | Router / firewall | Network | Edge UTM appliance, NAT + stateful firewall + VPN | Office rack | IT Admin | **Critical** | Configuration (Confidential) |
| A-04 | Network switch | Network | 24-port managed L2 switch, VLAN-capable | Office rack | IT Admin | **Medium** | Configuration |
| A-05 | Wi-Fi access points | Network | 2 × dual-band APs, corporate + guest SSID | Office ceiling | IT Admin | **High** | Internal |
| A-06 | Public web service | Software + Service | Company website + customer order portal on cloud VPS (Linux, Nginx, PHP, MySQL) | Cloud provider | Web Developer | **Critical** | Confidential (PII) |
| A-07 | Customer database | Data | ~8,000 customer records: name, email, phone, address, order history | On VPS (A-06) | Business Owner | **Critical** | Confidential / Regulated (DPDP Act 2023) |
| A-08 | Internet connectivity | Service | ISP fibre broadband, 200 Mbps, single circuit | Office | ISP / IT Admin | **High** | N/A |
| A-09 | Domain name and DNS records | Service | `northwindcraft.example` — A, MX, TXT/SPF records at registrar | Registrar (cloud) | IT Admin | **High** | Configuration |
| A-10 | Backup NAS | Hardware + Data | 2-bay NAS, nightly copy of file server | Office, same room as A-02 | IT Admin | **High** | Confidential |
| A-11 | Business email (Microsoft 365) | Service + Data | 25 mailboxes, quotations and invoices | Cloud (SaaS) | IT Admin | **High** | Confidential |
| A-12 | User accounts and credentials | Identity | 25 user accounts, 2 shared admin accounts, local admin rights on laptops | Local + M365 | IT Admin | **Critical** | Secret |

**Total assets inventoried: 12** (requirement: minimum 8)

---

## 1.4 Observations from the inventory

1. **Single points of failure.** A-03 (router/firewall) and A-08 (single ISP circuit) have no redundancy. A failure of either isolates the entire office.
2. **Backup co-location risk.** A-10 (backup NAS) sits in the same room as A-02 (file server). A fire, flood or theft destroys both copies simultaneously — this violates the 3-2-1 backup rule (3 copies, 2 media types, 1 offsite).
3. **Highest-value data is the most exposed.** A-07 (customer database) is the most sensitive asset and is also reachable from the public Internet through A-06.
4. **Identity is an asset, not just a setting.** A-12 is rated Critical because compromise of one admin credential grants access to A-02, A-03, A-04, A-05 and A-11 simultaneously — credentials are the connective tissue of the whole estate.
5. **Shadow assets.** Personal mobile phones used to read company email were discovered during the walkthrough but are not centrally managed. They are noted here as an inventory gap requiring a BYOD decision.

---

## 1.5 Asset-to-deliverable traceability

| Asset ID | Threats (Doc 02) | CIA assessment (Doc 03) | Controls (Doc 06) |
|---|---|---|---|
| A-01 | T-01, T-03, T-05 | Yes | C-01, C-02, C-05, C-08 |
| A-02 | T-02, T-06, T-11 | Yes | C-06, C-07, C-09 |
| A-03 | T-08, T-12 | Yes | C-03, C-04, C-10 |
| A-05 | T-07 | Yes | C-04 |
| A-06 / A-07 | T-04, T-09, T-10 | Yes | C-07, C-09, C-11 |
| A-12 | T-01, T-04 | Yes | C-01, C-02, C-05 |
