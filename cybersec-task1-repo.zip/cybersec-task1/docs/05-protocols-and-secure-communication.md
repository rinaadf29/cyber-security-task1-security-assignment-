# 5. Protocols and Secure Communication

This document explains what each core protocol does in Northwind's environment, how it can be attacked, and how it should be secured.

---

## 5.1 IP addressing — who is who on the network

**Role.** Every device needs a unique Layer 3 identifier so traffic can be routed to it. IP addressing is what makes the difference between "a packet" and "a packet that arrives".

**In this environment:**
- **Private addressing (RFC 1918).** Internal devices use `192.168.x.0/24` ranges. These are not routable on the public Internet, so no external host can reach a laptop directly.
- **NAT (Network Address Translation).** The firewall translates all internal private addresses to the single public address `203.0.113.10` on the way out. NAT is often described as a security feature; it is really an *address-conservation* feature whose side effect is that unsolicited inbound connections have nowhere to go. It is a useful byproduct, not a firewall.
- **Subnetting as a security boundary.** The `/24` mask means the first 24 bits identify the network and the last 8 identify the host: `192.168.10.0` is the network, `192.168.10.255` the broadcast, `.1–.254` the usable hosts. Placing servers in `192.168.20.0/24` and guests in `192.168.30.0/24` means the two cannot communicate without passing a firewall rule — segmentation is enforced by addressing.
- **Static vs dynamic.** Servers, switches and APs get static addresses (or DHCP reservations) so that firewall rules referring to them never break. Laptops get dynamic addresses.

**Security issues:** IP spoofing (forged source addresses), ARP spoofing on a flat LAN, and address exhaustion. **Controls:** anti-spoofing filters on the firewall (drop inbound packets claiming a private source address), dynamic ARP inspection on the switch, and correct subnet design.

---

## 5.2 DNS — the Internet's phone book

**Role.** DNS translates human-readable names into IP addresses. When a laptop requests `northwindcraft.example`, DNS returns `198.51.100.25`. Nothing works without it — a DNS outage is functionally identical to a total network outage.

**Resolution sequence:**

```
Laptop → browser cache → OS cache → hosts file
      → recursive resolver (ISP or internal)
      → root nameserver (.)
      → TLD nameserver (.example)
      → authoritative nameserver for northwindcraft.example
      → A record returned: 198.51.100.25  (cached for the TTL)
```

**Record types in use here:**

| Record | Purpose | Northwind example |
|---|---|---|
| A | Name → IPv4 address | `northwindcraft.example → 198.51.100.25` |
| AAAA | Name → IPv6 address | future use |
| CNAME | Alias to another name | `www → northwindcraft.example` |
| MX | Mail server for the domain | Microsoft 365 mail hosts |
| TXT | Free-form text, used for SPF/DKIM/DMARC and domain verification | `v=spf1 include:spf.protection.outlook.com -all` |
| NS | Which nameservers are authoritative | registrar's nameservers |

**Attacks:** DNS cache poisoning (injecting a false answer into a resolver), DNS hijacking (compromising the registrar account and editing records — the attack in T-12), typosquatting (`northwlndcraft.example`), and DNS tunnelling for data exfiltration.

**Why DNS hijacking is uniquely dangerous:** the attacker never touches Northwind's servers. Customers type the correct address, receive the attacker's IP, and see a convincing clone — and because the attacker can obtain a valid TLS certificate for a domain they control DNS for, the padlock appears too. The real server logs nothing unusual.

**Controls:** registrar-account MFA and registrar lock, DNSSEC (cryptographic signing of DNS responses), an internal resolver with DNS filtering to block known-malicious domains, DNS-over-HTTPS (DoH) or DNS-over-TLS to prevent on-path observation, monitoring of record changes, and domain auto-renewal.

---

## 5.3 DHCP — automatic address assignment

**Role.** DHCP hands out IP addresses, subnet masks, default gateways and DNS server addresses automatically. Without it, an administrator would configure 15 laptops by hand and every visitor would need manual setup.

**The DORA exchange** (all over UDP, ports 67 server / 68 client):

| Step | Message | Direction | Meaning |
|---|---|---|---|
| **D** | DISCOVER | Client → broadcast | "Is there a DHCP server out there?" |
| **O** | OFFER | Server → client | "Take 192.168.10.57, gateway .1, DNS .1, lease 8 hours" |
| **R** | REQUEST | Client → broadcast | "I accept that offer" (broadcast so other servers withdraw theirs) |
| **A** | ACK | Server → client | "Confirmed, it's yours until the lease expires" |

**In this environment:** VLAN 10 uses 8-hour leases from `.11–.200`; VLAN 30 guest uses 4-hour leases so addresses recycle quickly; VLAN 20 and 40 use static addresses or reservations.

**Attacks:** a **rogue DHCP server** (an attacker's device answering DISCOVER first, handing out its own IP as the gateway and DNS server — an instant man-in-the-middle over the entire subnet), and **DHCP starvation** (flooding requests with spoofed MACs to exhaust the pool, causing denial of service).

**Controls:** **DHCP snooping** on the managed switch — only the port connected to the legitimate DHCP server is marked "trusted", and OFFER messages from any other port are dropped. Combine with port security (MAC limits per port) and dynamic ARP inspection, which uses the DHCP snooping binding table.

---

## 5.4 TCP — reliable, connection-oriented transport

**Role.** TCP guarantees that data arrives complete, in order and error-checked. It is used wherever correctness matters more than speed.

**The three-way handshake:**

```
Client                                    Server
  │ ──── SYN (seq=x) ──────────────────────► │   "I want to connect"
  │ ◄─── SYN-ACK (seq=y, ack=x+1) ────────── │   "Acknowledged, I'm ready too"
  │ ──── ACK (ack=y+1) ────────────────────► │   "Confirmed — connection established"
```

Connections close with a four-way FIN/ACK exchange.

**Reliability mechanisms:** sequence numbers (ordering and duplicate detection), acknowledgements and retransmission of lost segments, checksums for error detection, sliding-window flow control, and congestion control.

**TCP services in this environment:**

| Port | Service | Notes |
|---|---|---|
| 443 | HTTPS | Customer portal, M365, all web traffic |
| 445 | SMB | File server shares — **must never be exposed to the Internet** |
| 22 | SSH | Encrypted admin access to the cloud VPS; key-based auth only |
| 3389 | RDP | **Currently forwarded from the firewall — must be closed** (V-07); replace with VPN + MFA |
| 3306 | MySQL | Database — bound to localhost only, never Internet-facing |
| 25 / 587 / 993 | SMTP / Submission / IMAPS | Email transport, all with TLS |

**Attacks:** SYN flooding (half-open connections exhausting the server's connection table — a DoS), session hijacking, and port scanning to map open services. **Controls:** SYN cookies and connection-rate limits on the firewall, default-deny inbound policy, and closing all management ports at the perimeter.

---

## 5.5 UDP — fast, connectionless transport

**Role.** UDP sends datagrams with no handshake, no ordering guarantee and no retransmission. It trades reliability for speed and low overhead, which suits short request/response exchanges and real-time media where a late packet is worse than a lost one.

**UDP services here:** DNS queries (53), DHCP (67/68), NTP time synchronisation (123), VPN transport (WireGuard/IPsec), and voice/video calls.

**TCP vs UDP compared:**

| Property | TCP | UDP |
|---|---|---|
| Connection | Connection-oriented (handshake) | Connectionless |
| Reliability | Guaranteed delivery, retransmission | Best effort, no retransmission |
| Ordering | Sequenced | No ordering guarantee |
| Speed / overhead | Slower, 20-byte header | Faster, 8-byte header |
| Flow / congestion control | Yes | No |
| Typical use | Web, file transfer, email, SMB | DNS, DHCP, NTP, VoIP, streaming, gaming |

**Security relevance:** because UDP is connectionless, source addresses are trivially spoofed. This enables **amplification and reflection DDoS** — an attacker sends a small spoofed DNS or NTP query to an open server, which sends a much larger reply to the victim. A 60-byte query can generate a multi-kilobyte response, multiplying attack traffic many times over. **Controls:** never run an open recursive DNS resolver, disable NTP `monlist`, apply source-address validation (BCP 38) and rate-limit UDP at the edge.

---

## 5.6 HTTP and HTTPS — the customer-facing protocols

### HTTP (TCP 80) — plaintext

HTTP is the request/response protocol of the web: the client sends a method (`GET`, `POST`, `PUT`, `DELETE`) with headers, and the server responds with a status code (200 OK, 301 Moved, 403 Forbidden, 404 Not Found, 500 Server Error) and a body.

**The problem is that everything is plaintext.** Anyone on the path — a compromised Wi-Fi network, a rogue DHCP gateway, an ISP, a proxy — can read every field, including submitted passwords, session cookies, addresses and order contents, and can silently modify the response. There is also no way for the client to verify it is talking to the real server.

### HTTPS (TCP 443) — HTTP inside TLS

HTTPS is the same HTTP wrapped in **TLS (Transport Layer Security)**, which provides three properties simultaneously:

| Property | How TLS achieves it | Which CIA pillar |
|---|---|---|
| **Encryption** | Symmetric session keys (AES-GCM, ChaCha20-Poly1305) encrypt all payload | Confidentiality |
| **Authentication** | The server presents an X.509 certificate signed by a trusted Certificate Authority, proving it controls the domain | Integrity (anti-spoofing) |
| **Message integrity** | An authentication tag (AEAD) detects any modification in transit | Integrity |

**The TLS 1.3 handshake, simplified:**

```
1. ClientHello   → supported cipher suites, TLS version, key-share (Diffie-Hellman)
2. ServerHello   ← chosen cipher suite, server key-share, X.509 certificate
3. Client verifies the certificate: valid CA signature? matching domain? not expired? not revoked?
4. Both sides independently derive the same symmetric session key via ECDHE
5. Encrypted application data flows
```

Two points worth understanding:

- **Asymmetric cryptography is used only to establish trust and agree a key; symmetric cryptography carries the actual data**, because it is far faster. Public-key operations are expensive; AES is not.
- **ECDHE gives forward secrecy.** The session key is derived ephemerally and never transmitted, so even if the server's private key is stolen a year later, previously recorded traffic cannot be decrypted retroactively.

### Findings and required actions for Northwind

| Finding | Risk | Action |
|---|---|---|
| TLS certificate expired 3 weeks ago (V-12) | Browsers show a full-page warning; customers abandon or click through and learn to ignore warnings | Renew immediately; automate with ACME/Let's Encrypt and monitor expiry |
| One portal path still served over HTTP | Session cookies and form data exposed in transit | Redirect all HTTP → HTTPS with 301 |
| No HSTS header | A downgrade attack can strip TLS before the redirect | Add `Strict-Transport-Security: max-age=31536000; includeSubDomains; preload` |
| Session cookies lack security flags | Cookie theft via XSS or plaintext transmission | Set `Secure`, `HttpOnly` and `SameSite=Strict` |
| Legacy TLS versions may be enabled | TLS 1.0/1.1 and weak ciphers are broken | Disable everything below TLS 1.2; prefer TLS 1.3 |

**Recommended additional security headers:** `Content-Security-Policy` (mitigates XSS), `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY` (clickjacking), and `Referrer-Policy: strict-origin-when-cross-origin`.

---

## 5.7 Protocol summary table

| Protocol | Layer | Transport / Port | Role at Northwind | Key risk | Secure alternative or control |
|---|---|---|---|---|---|
| IP | 3 Network | — | Addressing and routing | Spoofing | Anti-spoofing ACLs, segmentation |
| DNS | 7 Application | UDP/TCP 53 | Name resolution for web and email | Hijacking, poisoning | DNSSEC, DoH/DoT, registrar MFA + lock |
| DHCP | 7 Application | UDP 67/68 | Automatic IP configuration | Rogue DHCP server (MITM) | DHCP snooping, port security |
| ARP | 2 Data Link | — | IP → MAC resolution on the LAN | ARP spoofing | Dynamic ARP inspection |
| TCP | 4 Transport | — | Reliable delivery for web, SMB, SSH | SYN flood, hijacking | SYN cookies, rate limiting |
| UDP | 4 Transport | — | Fast delivery for DNS, DHCP, NTP, VPN | Amplification DDoS | BCP 38, rate limiting, no open resolvers |
| HTTP | 7 Application | TCP 80 | Legacy web access | Plaintext interception | **Redirect to HTTPS** |
| HTTPS / TLS | 6–7 | TCP 443 | All customer and staff web traffic | Expired or weak certificates | TLS 1.3, automated renewal, HSTS |
| SMB | 7 Application | TCP 445 | Internal file sharing | Ransomware propagation, WAN exposure | SMB 3 signing + encryption, never expose to Internet |
| SSH | 7 Application | TCP 22 | Encrypted server administration | Brute-force login | Key-based auth only, disable password login, fail2ban |
| SMTP / IMAP | 7 Application | TCP 25/587/993 | Business email | Spoofing, interception | STARTTLS, SPF + DKIM + DMARC |
| VPN (IPsec / WireGuard) | 3–4 | UDP 500/4500/51820 | Remote access for staff | Weak pre-shared keys | Certificate-based auth + MFA |
