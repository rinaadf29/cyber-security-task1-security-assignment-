# 3. CIA Triad Impact Assessment

---

## 3.1 What the CIA Triad is

The CIA Triad is the foundational model of information security. Every control, policy and technology in this report exists to protect one or more of these three properties.

### Confidentiality
**Information is accessible only to those authorized to see it.**

Confidentiality is about *disclosure*. It fails when data reaches someone who should not have it — whether through an attack, a misconfiguration, or an employee emailing the wrong attachment.

*Protected by:* encryption at rest and in transit, access control lists, least privilege, authentication and MFA, data classification, network segmentation, physical security.

*Failure looks like:* a customer database dumped on a forum; an unencrypted laptop stolen; the payroll folder readable by every employee.

### Integrity
**Information is accurate, complete and has not been altered without authorization.**

Integrity is about *trustworthiness*. It fails both maliciously (an attacker edits bank details on an invoice) and accidentally (a corrupted disk silently changes file contents). Integrity also covers **non-repudiation** — the ability to prove who did what.

*Protected by:* cryptographic hashing and digital signatures, checksums, TLS message authentication, version control, database transactions, audit logs, change management, input validation.

*Failure looks like:* ransomware encrypting files; SQL injection modifying order records; an attacker altering firewall rules; a spoofed email with changed payment details.

### Availability
**Information and systems are accessible to authorized users when needed.**

Availability is about *access*. It is the property most often broken by non-malicious causes — hardware failure, power cuts, expired certificates, botched updates — as well as by DDoS and ransomware.

*Protected by:* backups and tested restores, redundancy and failover, RAID, UPS and generators, capacity planning, patch and change management, DDoS protection, incident response and disaster recovery plans.

*Failure looks like:* the file server down for three days; the web portal offline during a sale; an expired TLS certificate blocking all customer access.

**The three properties pull against each other.** Air-gapping the file server maximises confidentiality and destroys availability. Giving everyone full control over all shares maximises availability and destroys confidentiality. Security engineering is the practice of choosing the right balance for each asset based on its business role — which is exactly what the table below does.

> Two extensions are worth noting: the **AAA** model (Authentication, Authorization, Accounting) describes *how* access decisions are made and recorded, and **non-repudiation** is often added as a fourth pillar alongside CIA in legal and transactional contexts.

---

## 3.2 CIA rating scale

| Rating | Meaning |
|---|---|
| **High (H)** | Compromise causes severe business, legal or financial harm |
| **Medium (M)** | Compromise causes noticeable disruption or limited harm |
| **Low (L)** | Compromise causes minimal harm |

---

## 3.3 CIA impact assessment for major assets

| Asset | C | I | A | Confidentiality impact if breached | Integrity impact if breached | Availability impact if lost |
|---|---|---|---|---|---|---|
| **A-01 Employee laptops** | **H** | M | M | Locally cached customer lists, quotations, saved browser credentials and offline email are exposed. No disk encryption (V-06) means a thief needs only a screwdriver, not a password. | Malware can alter local documents before they sync to the file server, propagating bad data upstream. | One user idle for 1–2 days. Work can shift to a spare machine, so operational impact is contained. |
| **A-02 File server** | **H** | **H** | **H** | Contains HR records, payroll, supplier contracts and design files. `Everyone: Full Control` (V-08) means any compromised user account exposes everything. | Silent modification of contracts, price lists or invoices would be trusted as authoritative — the server is the single source of truth. | Every employee loses access to working files simultaneously. Business stops within hours. RTO must be < 4 hours. |
| **A-03 Router / firewall** | **H** | **H** | **H** | Configuration reveals the internal topology, VPN pre-shared keys and firewall rule logic — a complete map for an attacker. | Rule tampering can silently open inbound access or redirect traffic while appearing normal in the UI. | Total loss of Internet, VPN and inter-VLAN routing. The entire office is offline. No redundant unit exists. |
| **A-04 Network switch** | M | **H** | **H** | Limited data value, but management access reveals VLAN and port mapping. | Port mirroring or VLAN reassignment enables undetected traffic capture — an integrity and confidentiality bridge. | All wired connectivity lost. Wi-Fi may survive if APs are powered independently. |
| **A-05 Wi-Fi access points** | **H** | M | M | A shared, never-rotated PSK (V-14) means one leaked passphrase grants any nearby party access to a flat internal network. | A rogue AP enables traffic injection and credential capture via captive-portal spoofing. | Wireless clients drop to wired only; laptops can be cabled as a workaround. |
| **A-06 Public web service** | **H** | **H** | **H** | The portal holds customer login sessions and order data. Expired TLS and a plaintext HTTP path (V-12) expose sessions in transit. | Defacement, injected malicious scripts or altered order/pricing data directly damages customers and revenue. | It is the primary sales channel. Every hour offline is lost revenue and visible reputational damage. |
| **A-07 Customer database** | **H** | **H** | **H** | ~8,000 records of personal data. Breach triggers notification duties under the DPDP Act 2023, regulatory penalty exposure and permanent trust loss. **Highest confidentiality asset in the estate.** | Altered addresses or order records cause mis-shipment, financial loss and disputes that are hard to unwind without audit logs (V-11). | Portal cannot process orders; the business cannot fulfil or verify customer commitments. |
| **A-09 Domain / DNS** | M | **H** | **H** | Registrar credentials themselves are the sensitive item, not the records. | **The critical one.** Hijacked records redirect all customers and email to an attacker while the real servers stay perfectly healthy. Users see no error. | Expiry or misconfiguration makes the website and all email globally unreachable within minutes of TTL expiry. |
| **A-10 Backup NAS** | **H** | **H** | **H** | Holds a full copy of everything the file server holds — identical confidentiality exposure, weaker protection. | If backups are corrupted or encrypted, restoration produces bad data and the corruption is only discovered during a crisis. | **The last line of defence.** Because it is writable and co-located (V-09), it fails in the same event as the primary — availability is effectively unprotected. |
| **A-11 Business email (M365)** | **H** | **H** | M | Mailboxes contain quotations, invoices, bank details and customer correspondence — the richest single source for fraud. | BEC alters payment instructions on genuine invoices; without DMARC (V-15) the domain can be spoofed outright. | SaaS with vendor-side redundancy; cloud availability is the strongest in the estate. |
| **A-12 Accounts / credentials** | **H** | **H** | M | A compromised admin credential is equivalent to compromising every other asset at once. Shared accounts (V-03) also destroy accountability. | Privilege escalation and unauthorized permission changes are invisible without audit logging. | Account lockout affects individuals, not the whole business. |

---

## 3.4 Priority conclusions

1. **A-07 (customer database) is the crown jewel.** Highest possible rating across all three properties, plus regulatory exposure. It deserves the largest share of the remediation budget.
2. **Availability is the weakest property overall.** The backup NAS is writable and co-located, the ISP circuit is single, and the firewall has no spare. A single fire in the server cupboard is currently an existential event for this business.
3. **Integrity is the least monitored property.** There is no file-integrity monitoring, no audit log review (V-11) and no change management. Integrity failures would likely be discovered by a customer complaint rather than by the organization.
4. **Identity (A-12) is a force multiplier in both directions.** Because it underwrites the confidentiality and integrity of every other asset, implementing MFA (C-02) is the single highest-return control in this report.
