# 4. Network Architecture Diagram

All addresses use IETF documentation ranges (RFC 5737 / RFC 1918) so that nothing in this report points at a real host.

---

## 4.1 Current state ("as-is") — flat network

This is the network as found. Everything sits in one broadcast domain (V-05).

```mermaid
graph TD
    INT["☁️ INTERNET<br/>Public networks"]
    ISP["ISP Fibre Circuit<br/>200 Mbps — single link<br/>Public IP 203.0.113.10"]
    FW["🛡️ ROUTER / FIREWALL — A-03<br/>NAT · Stateful firewall · VPN<br/>LAN gateway 192.168.1.1"]
    SW["🔀 L2 SWITCH — A-04<br/>24 ports · VLANs unconfigured<br/>Mgmt IP 192.168.1.2"]
    AP["📶 WI-FI APs ×2 — A-05<br/>SSID: Northwind-Corp / Northwind-Guest<br/>Both bridged to same LAN"]
    LAP["💻 EMPLOYEE LAPTOPS — A-01<br/>15 devices · DHCP<br/>192.168.1.100–199"]
    SRV["🗄️ FILE SERVER — A-02<br/>Windows Server 2019 · SMB<br/>Static 192.168.1.10"]
    NAS["💾 BACKUP NAS — A-10<br/>Writable share, same room<br/>Static 192.168.1.11"]
    GUEST["📱 Guest / BYOD devices<br/>Untrusted"]
    VPS["🌐 PUBLIC WEB SERVICE — A-06<br/>Cloud VPS · Nginx · PHP · MySQL<br/>198.51.100.25"]
    DB[("🔐 CUSTOMER DATABASE — A-07<br/>MySQL · 8,000 records")]
    DNS["🌍 DNS / REGISTRAR — A-09<br/>northwindcraft.example"]
    USERS["👥 Internet customers"]

    INT --- ISP
    ISP --- FW
    FW --- SW
    SW --- AP
    SW --- LAP
    SW --- SRV
    SW --- NAS
    AP --- GUEST
    INT --- VPS
    VPS --- DB
    INT --- DNS
    USERS --- INT

    classDef danger fill:#ffe0e0,stroke:#c0392b,stroke-width:2px
    classDef crit fill:#fff4d6,stroke:#d68910,stroke-width:2px
    class SW,AP,GUEST danger
    class SRV,NAS,DB,FW crit
```

### Problems visible in the as-is diagram

| # | Problem | Reference |
|---|---|---|
| 1 | Guest Wi-Fi devices can reach the file server and NAS directly — no segmentation | V-05, V-14 |
| 2 | Switch management interface is on the same subnet as user laptops | V-05, V-07 |
| 3 | Backup NAS is a writable SMB target on the production LAN — ransomware encrypts it alongside the server | V-09 |
| 4 | Firewall administration page is reachable from the WAN side | V-07 |
| 5 | No DMZ; no reverse proxy or WAF in front of the public web service | V-13 |
| 6 | Single ISP circuit and single firewall — no redundancy at the edge | A-03, A-08 |
| 7 | No IDS/IPS, no log collection, no network visibility | V-11 |

---

## 4.2 Target state ("to-be") — segmented network

This is the recommended architecture after applying the controls in Document 06.

```mermaid
graph TD
    INT["☁️ INTERNET"]
    CUST["👥 Customers"]
    CDN["🛡️ CDN + WAF + DDoS protection"]
    VPS["🌐 WEB SERVICE — A-06<br/>HTTPS only · TLS 1.3 · HSTS<br/>198.51.100.25"]
    DB[("🔐 DATABASE — A-07<br/>Private subnet<br/>No public IP · encrypted at rest")]
    ISP["ISP Circuit + 4G/5G failover"]
    FW["🛡️ NGFW — A-03<br/>Stateful FW · IPS · Content filter<br/>Site-to-site + client VPN w/ MFA<br/>Mgmt: LAN-only, no WAN exposure"]
    SW["🔀 MANAGED SWITCH — A-04<br/>802.1Q VLANs · DHCP snooping<br/>Port security · unused ports disabled"]

    V10["VLAN 10 — CORPORATE<br/>192.168.10.0/24<br/>💻 Laptops A-01"]
    V20["VLAN 20 — SERVERS<br/>192.168.20.0/24<br/>🗄️ File server A-02"]
    V30["VLAN 30 — GUEST WI-FI<br/>192.168.30.0/24<br/>📱 Internet-only, client isolation"]
    V40["VLAN 40 — BACKUP<br/>192.168.40.0/24<br/>💾 NAS A-10 — pull-based, immutable"]
    V99["VLAN 99 — MANAGEMENT<br/>192.168.99.0/24<br/>⚙️ Switch, AP and FW admin"]

    AP["📶 WI-FI APs — A-05<br/>WPA3-Enterprise (Corp)<br/>WPA3-Personal isolated (Guest)"]
    OFF["☁️ Offsite / cloud backup<br/>3-2-1 rule · immutable copy"]

    CUST --> INT
    INT --> CDN --> VPS --> DB
    INT --- ISP --- FW
    FW --- SW
    SW --- V10
    SW --- V20
    SW --- V30
    SW --- V40
    SW --- V99
    SW --- AP
    AP -.->|Corp SSID → VLAN 10| V10
    AP -.->|Guest SSID → VLAN 30| V30
    V40 -.->|encrypted replication| OFF

    classDef good fill:#e0f5e9,stroke:#27ae60,stroke-width:2px
    classDef mgmt fill:#e6efff,stroke:#2e5fa3,stroke-width:2px
    class CDN,OFF,FW good
    class V99,V40 mgmt
```

### Inter-VLAN firewall policy (default deny)

| Source | Destination | Ports allowed | Rationale |
|---|---|---|---|
| VLAN 10 Corporate | VLAN 20 Servers | TCP 445 (SMB), 88/389/636 (AD) | Users need file shares and authentication only |
| VLAN 10 Corporate | Internet | TCP 80/443, UDP 53 (to internal resolver) | Normal browsing via content filter |
| VLAN 30 Guest | Internet | TCP 80/443, UDP 53 | **Internet only — explicitly denied to all internal VLANs** |
| VLAN 30 Guest | VLAN 10/20/40/99 | **DENY ALL** | Core segmentation boundary |
| VLAN 20 Servers | VLAN 40 Backup | **DENY** (backup *pulls* from server) | Prevents ransomware on the server reaching backups |
| VLAN 40 Backup | VLAN 20 Servers | TCP 445 (read-only, scheduled) | Pull-based backup model |
| Any | VLAN 99 Management | **DENY** except jump host from VLAN 10 with MFA | Management plane isolation |
| Internet | Any internal VLAN | **DENY ALL** inbound; remote access via VPN + MFA only | No port forwarding, no exposed RDP |

---

## 4.3 IP addressing plan

| Segment | Subnet | Usable range | Gateway | Assignment | Devices |
|---|---|---|---|---|---|
| WAN | 203.0.113.10/30 | — | ISP | Static (ISP) | Firewall WAN interface |
| VLAN 10 Corporate | 192.168.10.0/24 | .11 – .200 | 192.168.10.1 | DHCP | Employee laptops, printers |
| VLAN 20 Servers | 192.168.20.0/24 | .10 – .50 | 192.168.20.1 | Static / DHCP reservation | File server (.10) |
| VLAN 30 Guest | 192.168.30.0/24 | .50 – .200 | 192.168.30.1 | DHCP, 4-hour lease | Guest phones, BYOD |
| VLAN 40 Backup | 192.168.40.0/24 | .10 – .20 | 192.168.40.1 | Static | NAS (.10) |
| VLAN 99 Management | 192.168.99.0/24 | .2 – .20 | 192.168.99.1 | Static | Switch (.2), APs (.3–.4), FW mgmt (.1) |
| Cloud (public) | 198.51.100.25/32 | — | Provider | Static | Public web service |

A `/24` gives 254 usable hosts per VLAN — far more than needed for 25 staff, which leaves headroom and keeps the plan readable. Subnet boundaries are deliberately aligned to VLAN IDs (VLAN 10 → 192.168.**10**.0/24) so that an address alone identifies its security zone.

---

## 4.4 Mapping the architecture to the OSI and TCP/IP models

| OSI layer | TCP/IP layer | Where it appears in this network | Security control at this layer |
|---|---|---|---|
| **7 Application** | Application | HTTP/HTTPS portal, SMB shares, DNS, SMTP email | WAF, input validation, content filtering, email authentication |
| **6 Presentation** | Application | TLS encryption and certificates, character encoding, compression | TLS 1.3, strong cipher suites, certificate management |
| **5 Session** | Application | TLS session establishment, SMB sessions, VPN tunnels | Session timeouts, secure cookie flags, re-authentication |
| **4 Transport** | Transport | TCP 443/445/22, UDP 53/67/123 | Stateful firewall rules, port filtering, SYN-flood protection |
| **3 Network** | Internet | IP addressing, routing, NAT, inter-VLAN routing, ICMP | ACLs, network segmentation, IPsec, anti-spoofing |
| **2 Data Link** | Network Access | Ethernet frames, MAC addresses, 802.1Q VLAN tags, Wi-Fi (802.11) | Port security, DHCP snooping, dynamic ARP inspection, WPA3 |
| **1 Physical** | Network Access | Cat6 cabling, fibre, RF spectrum, ports and racks | Locked rack and server cupboard, disabled unused ports, cable management |

**The practical lesson:** attacks occur at every layer, so controls must too. A perfect firewall at Layer 3/4 does nothing against SQL injection at Layer 7, and TLS at Layer 6 does nothing against someone who walks into an unlocked server cupboard at Layer 1. This is why the control set in Document 06 spans all seven layers — the principle of **defence in depth**.

---

## 4.5 Rendering the diagram

Both diagrams above are written in Mermaid and render automatically in GitHub's markdown viewer. A standalone SVG version is also provided at [`../diagrams/network-diagram.svg`](../diagrams/network-diagram.svg) for use in slides or printed copies.
